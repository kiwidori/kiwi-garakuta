'use strict';
importScripts('config.js','core.js');
const ENDPOINT=TrophyCore.endpoint(self.TROPHY_ENDPOINT);
let publicCache=null,lastPublic=0,lastClaim=0;const tabs=new Map();
const defaults={enabled:true,token:'',name:'',pending:null,lastStatus:''};
async function settings(){return {...defaults,...await chrome.storage.local.get(Object.keys(defaults))};}
async function call(path,body,auth=true){
  const s=await settings();
  const response=await fetch(ENDPOINT+path,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),...(auth&&s.token?{Authorization:'Bearer '+s.token}:{})},
    body:body?JSON.stringify(body):undefined,redirect:'error',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(12000)});
  const data=await response.json().catch(()=>({}));
  if(!response.ok){
    if(response.status===401&&auth&&s.token)await chrome.storage.local.set({token:'',name:'',lastStatus:'連携が切れました。もう一度連携してください'});
    const error=new Error(data.error||'サーバーに接続できません');error.status=response.status;throw error;
  }
  return data;
}
async function publicConfig(){if(publicCache&&Date.now()-lastPublic<15000)return publicCache;publicCache=await call('/api/public',undefined,false);lastPublic=Date.now();return publicCache;}
async function startLink(){
  const s=await settings();
  if(s.pending&&Date.now()<s.pending.expires-60000)return s.pending;
  const r=await call('/api/link/start',{},false);
  const pending={code:r.code,claim:r.claim,expires:r.expires*1000};
  await chrome.storage.local.set({pending,lastStatus:''});return pending;
}
async function checkLink(force){
  const s=await settings();
  if(s.token)return {linked:true,name:s.name};
  if(!s.pending)return {pending:false};
  if(Date.now()>s.pending.expires){await chrome.storage.local.set({pending:null});return {expired:true};}
  if(!force&&Date.now()-lastClaim<5000)return {pending:true};
  lastClaim=Date.now();
  try{
    const r=await call('/api/link/claim',{claim:s.pending.claim},false);
    if(r.pending)return {pending:true};
    await chrome.storage.local.set({token:r.token,name:r.name,pending:null,enabled:true,lastStatus:''});publicCache=null;tabs.clear();
    return {linked:true,name:r.name};
  }catch(e){if(e.status===410){await chrome.storage.local.set({pending:null});return {expired:true};}throw e;}
}
async function fromYouTube(message,sender){
  const u=new URL(sender.tab.url||'about:blank');
  if(u.origin!=='https://www.youtube.com'||sender.frameId!==0)throw new Error('送信元が不正です');
  const s=await settings();
  if(message.type==='public'){
    if(!s.token&&s.pending)checkLink(false).catch(()=>{});   // チャットに合言葉を書いた直後に自動で連携完了
    if(!s.token||!s.enabled)return null;
    return {video:(await publicConfig()).video};
  }
  if(message.type!=='sample'||u.pathname!=='/watch'||u.searchParams.get('v')!==message.video)throw new Error('動画が一致しません');
  if(!s.enabled||!s.token)return {ok:false};
  const cfg=await publicConfig();if(!cfg.video?.is_live||cfg.video.id!==message.video)return {ok:false};
  if(!Number.isFinite(message.seconds)||message.seconds<0||message.seconds>8||typeof message.device!=='string'||message.device.length>128)throw new Error('計測値が不正です');
  const old=tabs.get(sender.tab.id);const now=Date.now();const same=old&&old.device===message.device&&old.video===message.video;
  const entry=same?old:{device:message.device,video:message.video,seconds:0,sent:0,seen:now};
  if(now-entry.seen>22000)entry.seconds=0;
  entry.seen=now;entry.seconds+=message.seconds;tabs.set(sender.tab.id,entry);
  if(now-entry.sent<10000)return {ok:true};
  const seconds=Math.min(20,entry.seconds);entry.seconds=0;entry.sent=now;
  try{const r=await call('/api/heartbeat',{video:message.video,device:entry.device,sequence:message.sequence,seconds});await chrome.storage.local.set({lastStatus:r.reason,lastSent:now});return r;}
  catch(e){await chrome.storage.local.set({lastStatus:e.message});if(e.status===409)publicCache=null;throw e;}
}
async function fromUI(message){
  switch(message.type){
    case 'status':{const s=await settings();return {linked:!!s.token,name:s.name,enabled:s.enabled,pending:s.pending?{code:s.pending.code,expires:s.pending.expires}:null,lastStatus:s.lastStatus,endpoint:ENDPOINT};}
    case 'link':{const p=await startLink();return {code:p.code,expires:p.expires};}
    case 'new-code':{await chrome.storage.local.set({pending:null});const p=await startLink();return {code:p.code,expires:p.expires};}
    case 'check':return checkLink(true);
    case 'toggle':await chrome.storage.local.set({enabled:!!message.enabled,lastStatus:message.enabled?'視聴時間の記録を再開しました':'視聴時間の記録を止めました'});tabs.clear();return {ok:true};
    case 'me':return call('/api/me');
    case 'delete':await call('/api/me/delete',{});await chrome.storage.local.set({token:'',name:'',pending:null,lastStatus:'記録を削除しました'});tabs.clear();return {ok:true};
    case 'disconnect':{const s=await settings();if(s.token)await call('/api/logout',{}).catch(()=>{});await chrome.storage.local.set({token:'',name:'',pending:null,lastStatus:'連携を解除しました'});tabs.clear();return {ok:true};}
  }
  throw new Error('不明な操作です');
}
async function handle(message,sender){
  if(sender.tab&&!sender.url?.startsWith(chrome.runtime.getURL('')))return fromYouTube(message,sender);
  if(!sender.url?.startsWith(chrome.runtime.getURL('')))throw new Error('操作元が不正です');
  return fromUI(message);
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{handle(message,sender).then(data=>reply({ok:true,data}),e=>reply({ok:false,error:e.message||'接続できません'}));return true;});
chrome.tabs.onRemoved.addListener(id=>tabs.delete(id));
chrome.runtime.onInstalled.addListener(d=>{if(d.reason==='install')chrome.tabs.create({url:chrome.runtime.getURL('popup.html?welcome=1')});});
