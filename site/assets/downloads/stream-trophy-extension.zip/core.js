(function(root){
  'use strict';
  function endpoint(value){const u=new URL(value);if(u.username||u.password||u.search||u.hash||!['','/'].includes(u.pathname))throw new Error('接続先の形式が不正です');if(u.protocol!=='https:'&&!(u.protocol==='http:'&&['127.0.0.1','localhost'].includes(u.hostname)))throw new Error('接続先はHTTPSが必要です');return u.origin;}
  function playable(s){return !!(s&&s.video&&s.target&&s.video===s.target&&s.live&&!s.ad&&!s.paused&&!s.ended&&!s.seeking&&s.ready>=3&&s.rate>0&&Number.isFinite(s.position));}
  function watched(previous,current){if(!playable(previous)||!playable(current)||previous.video!==current.video)return 0;const elapsed=(current.at-previous.at)/1000;const moved=current.position-previous.position;if(elapsed<=0||elapsed>8||moved<=0||moved>elapsed*Math.max(previous.rate,current.rate)+1)return 0;return Math.min(elapsed,moved/Math.max(previous.rate,current.rate));}
  const api={endpoint,playable,watched};root.TrophyCore=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
