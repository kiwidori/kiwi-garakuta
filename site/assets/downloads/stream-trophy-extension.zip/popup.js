'use strict';
const $=s=>document.querySelector(s);let timer;
async function send(body){const r=await chrome.runtime.sendMessage(body);if(!r?.ok)throw new Error(r?.error||'拡張に接続できません');return r.data;}
function status(text,error=false){$('#status').textContent=text||'';$('#status').className=error?'error':'';}
function showCode(p){$('#code').textContent='!link '+p.code;const min=Math.max(0,Math.round((p.expires-Date.now())/60000));$('#expires').textContent='有効期限：あと約'+min+'分';}
async function load(){
  clearTimeout(timer);
  const s=await send({type:'status'});
  $('#linked').hidden=!s.linked;$('#unlinked').hidden=s.linked;
  if(s.linked){
    $('#name').textContent=(s.name||'あなた')+' さんのコレクション';$('#enabled').checked=s.enabled;status(s.lastStatus);
    try{const d=await send({type:'me'});$('#watch').textContent=(d.viewer.watch_seconds/3600).toLocaleString('ja-JP',{maximumFractionDigits:1});$('#count').textContent=d.viewer.awards.length;}catch(e){status(e.message,true);if(!(await send({type:'status'})).linked)return load();}
    return;
  }
  $('#welcome').hidden=!location.search.includes('welcome');
  try{showCode(await send({type:'link'}));status(s.lastStatus||'書き込みを待っています…');poll();}catch(e){status(e.message,true);}
}
async function poll(){
  try{const r=await send({type:'check'});if(r.linked){status(r.name+' さんとして連携しました。違う場合は「連携を解除」してください');return load();}if(r.expired)return load();}catch(e){status(e.message,true);}
  timer=setTimeout(poll,3000);
}
$('#copy').onclick=async()=>{try{await navigator.clipboard.writeText($('#code').textContent);status('コピーしました。チャット欄に貼り付けて送信してください');}catch{status('コピーできませんでした。手で入力してください',true);}};
$('#new-code').onclick=async()=>{try{showCode(await send({type:'new-code'}));}catch(e){status(e.message,true);}};
$('#enabled').onchange=async e=>{try{await send({type:'toggle',enabled:e.target.checked});status(e.target.checked?'記録を再開しました':'記録を止めました');}catch(err){status(err.message,true);}};
$('#open-collection').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('collection.html')});
$('#privacy').onclick=e=>{e.preventDefault();chrome.tabs.create({url:self.TROPHY_ENDPOINT+'/privacy'});};
$('#disconnect').onclick=async()=>{try{await send({type:'disconnect'});await load();}catch(e){status(e.message,true);}};
$('#delete').onclick=async()=>{if(!confirm('コメント数・視聴時間・トロフィーをすべて削除し、今後も記録しないようにします。よろしいですか？\n（もう一度連携すると再開できます）'))return;try{await send({type:'delete'});await load();}catch(e){status(e.message,true);}};
load().catch(e=>status(e.message,true));
