'use strict';
// YouTubeの再生状態を読むだけ。動画の操作や、ページ内容の送信はしない。
(() => {
  const device=crypto.randomUUID();let previous=null,settings=null,configAt=0,sampling=false;
  const send=async body=>{const r=await chrome.runtime.sendMessage(body);if(!r?.ok)throw new Error(r?.error||'接続できません');return r.data;};
  async function tick(){if(sampling)return;sampling=true;try{
    if(Date.now()-configAt>15000){settings=await send({type:'public'});configAt=Date.now();}
    const id=location.pathname==='/watch'?new URLSearchParams(location.search).get('v'):null;
    if(!settings?.video||id!==settings.video.id){previous=null;return;}
    const video=document.querySelector('video.html5-main-video');
    const sample={at:performance.now(),video:id,target:settings.video.id,live:settings.video.is_live===true,
      ad:!!document.querySelector('#movie_player.ad-showing, #movie_player.ad-interrupting'),
      paused:video?.paused??true,ended:video?.ended??true,seeking:video?.seeking??true,
      ready:video?.readyState??0,rate:video?.playbackRate??0,position:video?.currentTime??0};
    const seconds=TrophyCore.watched(previous,sample);previous=sample;
    if(TrophyCore.playable(sample))await send({type:'sample',video:id,seconds,device,sequence:Date.now()});
  }catch{previous=null;settings=null;configAt=0;}finally{sampling=false;}}
  for(const type of ['pause','waiting','seeking','emptied','ended','ratechange'])document.addEventListener(type,()=>previous=null,true);
  document.addEventListener('yt-navigate-start',()=>{previous=null;configAt=0;});
  setInterval(tick,5000);tick();
})();
