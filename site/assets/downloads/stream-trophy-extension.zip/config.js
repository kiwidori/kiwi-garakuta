self.TROPHY_ENDPOINT = "https://stream-trophies.kiwi-tech-tech.workers.dev";
